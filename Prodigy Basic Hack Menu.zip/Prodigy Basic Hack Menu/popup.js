document.addEventListener("DOMContentLoaded", function() {
  const cB = document.getElementById("copy-button");
  const sT = document.getElementById("script-text");
  const chB = document.getElementById("channel-button");
  const hB = document.getElementById("help-button");
  
  // Copy script text to clipboard
  cB.addEventListener("click", function() {
    const sTt = sT.textContent.trim();
    navigator.clipboard.writeText(sTt)
      .then(() => alert("Script copied to clipboard!"))
      .catch(e => console.error("Failed to copy the script:", e));
  });
  
  // Open a new tab to the YouTube channel
  chB.addEventListener("click", function() {
    window.open("https://www.youtube.com/@CrackinPMG", "_blank");
  });
  
  // Open a new tab to the help site
  hB.addEventListener("click", function() {
    window.open("https://crackinpmg.my.canva.site/crackinpmg-hack-menu-help", "_blank");
  });
});
